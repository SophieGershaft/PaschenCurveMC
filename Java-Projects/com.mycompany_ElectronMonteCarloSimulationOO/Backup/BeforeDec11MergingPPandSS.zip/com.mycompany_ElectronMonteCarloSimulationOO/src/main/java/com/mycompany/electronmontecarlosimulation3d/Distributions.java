/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.electronmontecarlosimulation3d;

import java.util.Random;

/**
 *
 * @author sgershaft
 */
public class Distributions {

    // lambda is mean free path
    public static double cdfExponential(double lambda, Random random) {
        // cumulative distribution function
        // makes exponential distribution from uniform distribution
        double u = Math.random();
        return -lambda * Math.log(1 - u);
        // NOTE: JUST MADE A HUGE CHANGE THAT MAY OR MAY NOT FIX A HUGE BUG
    }  
    
}
