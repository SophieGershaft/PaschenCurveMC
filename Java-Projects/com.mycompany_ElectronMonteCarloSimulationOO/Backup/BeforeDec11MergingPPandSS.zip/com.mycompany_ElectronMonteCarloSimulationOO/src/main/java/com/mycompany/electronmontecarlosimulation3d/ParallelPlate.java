/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.electronmontecarlosimulation3d;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author sgershaft
 */
public class ParallelPlate implements IGeometry {

    double d;
    double V;
    ThreadLocalRandom random;

    public ParallelPlate(ThreadLocalRandom random) {
        d = SettingsPP.getInstance().getD();
        this.V = SettingsPP.getInstance().getVoltage();
        this.random = random;
    }

    // check whether electron is inside or on the cathode
    @Override
    public boolean isCathode(Vector r) {
        // if x component of r is <= radius to cathode --> on or inside cathode
        return (r.x < d);
    }

    @Override
    public boolean isAnode(Vector r) {
        // if x component of r is >= radius to anode --> on or outside anode
        return (r.x >= d);
    }

    @Override
    public Vector getEfield(Vector pos) {
        Vector Efield = new Vector(-V/d, 0, 0);
        return Efield;
    }
    
    @Override
    public double getPotential(Vector pos) {
        double Potential = (pos.x * V)/d;
        return Potential;
    }

    @Override
    public Vector cathodeStart() {
        // it doesn't matter where it starts on the plate because only the x-direction really matters
        Vector start = new Vector(0, 0, 0);
        return start;
    }
}
