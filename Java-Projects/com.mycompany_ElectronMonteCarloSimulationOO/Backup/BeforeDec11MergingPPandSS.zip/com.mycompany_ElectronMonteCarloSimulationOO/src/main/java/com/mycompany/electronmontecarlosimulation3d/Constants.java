/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.electronmontecarlosimulation3d;

/**
 *
 * @author sgershaft
 */
public class Constants {
    
    public static final double e = 1; // 1 electron charge (charge of electron)
    public static final double m = 511000; // in eV bc m_e = 511,000 eV
//    public static final double delta_t = 1e-3;
    
}
