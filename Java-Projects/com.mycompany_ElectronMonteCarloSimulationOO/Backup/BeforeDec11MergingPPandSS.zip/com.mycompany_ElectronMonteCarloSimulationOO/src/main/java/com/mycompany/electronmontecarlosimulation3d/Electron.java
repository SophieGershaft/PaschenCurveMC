//@@ -0,0 +1,212 @@
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.electronmontecarlosimulation3d;

import java.util.ArrayList;
import org.apache.commons.math3.analysis.function.Asinh;

/**
 *
 * @author sgershaft
 */
public class Electron {

    Vector position; // in meters
    Vector velocity; // number, fraction of C (just like beta)

//    boolean showPath;// showPath enables printing positions of collisions TO DO
    public static final double e = 1; // 1 electron charge (charge of electron)
    public static final double m = 511000; // in eV bc m_e = 511,000 eV
    public double E = SettingsPP.getInstance().getE();
    public double delta_t = SettingsPP.getInstance().getDeltaT();

    public Electron(Vector startPosition, Vector startVelocity, boolean printThings) {
        this.position = startPosition;
        this.velocity = startVelocity;
    }

    public void printPosVel() {
//        System.out.format("x: %10.5f %10.5f %10.5f v: %10.5f %10.5f %10.5f \n", position.x, position.y, position.z, velocity.x, velocity.y, velocity.z);
    }

    public double setNewPositionsV2(double s) {

        printPosVel();
//        System.out.format("s: %10.5f \n", s);
        // save old things
        double x0 = position.x;
        double v = velocity.getNorm();
        double K_i = 0.5 * this.m * v * v;

        double path = 0;
        double R;
        // Euler's method
        while (path < s) {
//           System.out.format("path: %10.5f \n", path);
            R = position.getNorm();
            // increment position
            Vector deltaPosition = velocity.multiplyByScalar(delta_t);
            position = position.addVectors(deltaPosition);

            // increment velocity
            double constant = (e * E) / m * delta_t;
            Vector deltaVelocity = new Vector(constant, 0, 0);
            velocity = velocity.addVectors(deltaVelocity);

            path += deltaPosition.getNorm();
//           System.out.format("path: %10.5f \n", path);
        }

        printPosVel();

        // find total energy
        double x1 = this.position.x;

        // should be diff between U when working in diff geometry
        double deltaU = e * SettingsPP.getInstance().getE() * (x1 - x0);
        double K_f = 0.5 * m * this.velocity.Square();
        double delta_energy = ((K_f - K_i) - (e * SettingsPP.getInstance().getE() * (x1-x0)));

//        System.out.format("K_i: %.3f, K_f: %.3f, deltaU: %.3f \n", K_i, K_f, deltaU);
//        System.out.println("delta energy (should be ~0)" + delta_energy);
        
        // NEW!!!
        // return a delta_energy for RMS
        return delta_energy;
    }

    public void forwardScatter(double energyLoss, double minCos) {
        double v0 = velocity.getNorm();
        double Ki = 0.5 * m * v0 * v0;
        double Kf = Ki - energyLoss;

        if (Kf < 0.0) {
            velocity.x = 0;
            velocity.y = 0;
            velocity.z = 0;
            return;
        }

        // make a set of basis vectors where basis1 is the original velocity direction
        Vector basis1 = velocity.getUnitVector();
        Vector basis2 = basis1.constructPerpendicular();
        Vector basis3 = basis1.getCrossProduct(basis2);

        double cosTheta = (1.0 - minCos) * Math.random() + minCos; // random in range minCos to 1.0
        double sinTheta = Math.sqrt(1.0 - cosTheta * cosTheta);
        double phi = 2.0 * Math.PI * Math.random(); // random from 0 to 2pi

        // v norm
        double v1 = Math.sqrt((2.0 * Kf) / m);
        Vector v_b1 = basis1.multiplyByScalar(cosTheta * v1);
        Vector v_b2 = basis2.multiplyByScalar(sinTheta * Math.cos(phi) * v1);
        Vector v_b3 = basis3.multiplyByScalar(sinTheta * Math.sin(phi) * v1);
        
        Vector v_b1_b2 = v_b1.addVectors(v_b2);
        Vector velocity1 = v_b1_b2.addVectors(v_b3);
        velocity = velocity1;
    }

    //   Get Velocity
    // TO DO: ONLY getEnergy()
//    public void setVelocity(double cosTheta, double phi, Vector v_c, double delta_x) {
//        // _c means before collision and _f means after collision
//        // (U_c is electric potential energy gained bc of electric field)
//        double v_c_mag = v_c.getNorm();
//        double K_c = 0.5 * m * v_c_mag * v_c_mag;
//        double U_c = e * SettingsPP.getInstance().getE() * delta_x;
//        double Energy_f = K_c + U_c;
//        
//        
//
//        double v_f_mag = Math.sqrt((2 * Energy_f) / m);
//        double v_x = v_f_mag * cosTheta * Math.cos(phi);
//        double v_y = v_f_mag * Math.cos(phi) * Math.sqrt(1 - cosTheta * cosTheta);
//        double v_z = v_f_mag * Math.sin(phi);
//
//        // vector velocity to return
//        Vector newvelocity = new Vector(v_x, v_y, v_z);
//        this.velocity = newvelocity;
//    }
    // Subtract UI
    // ✔ TO DO: SUBTRACTION OF ENERGY SHOULD BE IN SIMULATION CLASS
    // ✔ SHOULD ASK ENERGY (GET ENERGY)
    // CALL ELECTRON CLASS TO SCATTER BUT W/ NEW ENERGY
//    public Vector adjustEnergy(double cosTheta, double phi, Vector velocity0, boolean ionized) {
//        double v0 = velocity0.getNorm();
//        double energy = 0.5 * Constants.m * v0 * v0;
//        
//        if (ionized) {
//            energy -= SettingsPP.getInstance().getUI();
//        } else {
//            double randombit = ((int)Math.floor((Math.random() * 5)+1))/10.0;
//            // NEED TO TEST AND DEBUG RANDOMBIT TO MAKE SURE IT DOES WHAT'S 
//            energy -= SettingsPP.getInstance().getUI() * randombit;
//        }
//        if (energy < 0) {
//            energy = 0;
//        }
//        
//        double v1 = Math.sqrt((2*energy)/Constants.m);
//        double vx = v1 * cosTheta * Math.cos(phi);
//        double vy = v1 * Math.cos(phi) * Math.sqrt(1 - cosTheta*cosTheta);
//        double vz = v1 * Math.sin(phi);
//        
//        Vector velocity = new Vector(vx, vy, vz);
//        return velocity;
//    }
    // check ionization
    boolean checkIonization(double v) {
        double energy = 0.5 * this.m * v * v; // in eV

        // FOR DEBUGGING
//        System.out.println("energy: " + energy);
        double Ui = SettingsPP.getInstance().getUI();
        if (energy >= Ui) {
            return true;
        }
        return false;
    }

    // why 1? NEW CHANGE: 1 
//    private double calculateS_of_t(double t) {
//        // calculate distance S from an input t (guess time of collision)
//        // use solution of s
//        Asinh asinh = new Asinh();
//        double a_x = SettingsPP.getInstance().getAx();
//        double v_x = velocity.x;
//        double v_w = velocity.getTransverseComponent();
//        double atvx = (a_x * t + v_x);
//        double vw2 = v_w * v_w;
//        double s;
////        if (v_w <= 1e-6) { (MY VERSION)
//        if (v_w <= 1e-6 * Math.abs(v_x)) {
//            s = (atvx * Math.abs(atvx) - (v_x * Math.abs(v_x))) / (2.0 * a_x);
//        } else {
//            s = (1.0 / (2.0 * a_x)) * (atvx * Math.sqrt(vw2 + atvx * atvx)
//                    - v_x * Math.sqrt(vw2 + v_x * v_x)
//                    + vw2 * (asinh.value(atvx / v_w) - asinh.value(v_x / v_w)));
////            double g = asinh.value(atvx / v_w);
////            System.out.format("atvx / v_w: %10.5f asinh(atvx / v_w): %10.5f, sinh(atvx / v_w: %10.5f \n", (atvx / v_w), g, Math.sinh(g));
//        }
////        System.out.format("t = %10.5f, s(t) = %10.5f \n", t, s);
//        return s;
//    }
//    // should be interior of integral
//    private double calculateV_c(double t_c) {
//        // calculates velocity before collision
//        // v_x and v_w are velocities from after previous collision
//        // v_c is value from integral
//        double a_x = SettingsPP.getInstance().getAx();
//        double v_x = velocity.x;
//        double v_w = velocity.getTransverseComponent();
//        return Math.sqrt(v_w * v_w + (v_x + a_x * t_c) * (v_x + a_x * t_c));
//    }
//
//    // TODO: make test program to verify getTime (call w/ same parameters and prove that it's the same)
//    private double getTime(double s) {
//        // calculate time at next collision using kinematics
//        double t = Constants.delta_t;
//        double tolerance = SettingsPP.getInstance().getTolerance();
//        double guessDistance = calculateS_of_t(t);
//        while (Math.abs(s - guessDistance) > tolerance) {
//            // change t using Newton's Method
//            // x_n+1 = x0 - f(x_n)/f'(x_n)
//            // so:
//            // t_n+1 = t0 - s(t_n)/v(t_n)
//            
//            double v_c = calculateV_c(t);
//            if (v_c == 0) {
//                t+=1;
//            } else {
//                t = t - (guessDistance - s) / calculateV_c(t);
//            }
//            guessDistance = calculateS_of_t(t);
//            // QUESTION: What do I do if V_c = 0? Division by 0 bad. This happens if initial t = 0
//            // Should I make initial t other than 0
//        }
//        return t;
//    }
}
